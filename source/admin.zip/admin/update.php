<?php

$page = $_GET['action'];

if(strpos($page,"plugin_") !== false){
	
}

?>