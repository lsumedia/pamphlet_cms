<?php

/* 
 * public.php
 * Sends JSON responses for requests for public pages
 * If 
 */

if(isset($_GET['debug'])){	//Error reporting - disable for production
ini_set('display_errors',1);
ini_set('display_startup_errors',1);
error_reporting(-1);
}else{
    ini_set('display_errors',0);
    ini_set('display_startup_errors',0);
    error_reporting(0);
}

require 'connect.php';
require 'functions/data_wrangler.php';
require 'functions/elements.php';


//Current internal pages

$pages = new standardOptionsPages();
$pages->configure();

if(isset($_GET['action'])){
    $action = filter_input(INPUT_GET,'action');
    
    if($page = $pages->matchObject($action)){
        try{
            $page->displayPage();
        }catch(Exception $e){
            "Error - could not perform that action: $e";
        }
    }else{
        echo "Error - Page $action does not exist";
    }
}else{
    echo "Error - Empty page request";
}