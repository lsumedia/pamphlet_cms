﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'iframe', 'ja', {
	border: 'フレームの枠を表示',
	noUrl: 'iframeのURLを入力してください。',
	scrolling: 'スクロールバーの表示を許可',
	title: 'iFrameのプロパティ',
	toolbar: 'IFrame'
} );
