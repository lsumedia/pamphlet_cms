﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'iframe', 'nl', {
	border: 'Framerand tonen',
	noUrl: 'Vul de IFrame URL in',
	scrolling: 'Scrollbalken inschakelen',
	title: 'IFrame-eigenschappen',
	toolbar: 'IFrame'
} );
