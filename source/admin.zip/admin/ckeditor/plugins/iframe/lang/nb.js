﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'iframe', 'nb', {
	border: 'Viss ramme rundt iframe',
	noUrl: 'Vennligst skriv inn URL for iframe',
	scrolling: 'Aktiver scrollefelt',
	title: 'Egenskaper for IFrame',
	toolbar: 'IFrame'
} );
